import { useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import React, { useCallback, useMemo, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { TOPIC_BY_ID } from "../../../../data/catalog";
import { loadProgress } from "../../../../src/state/progress";
import { useStreak } from "../../../../src/state/useStreak";
import { useTotalXp } from "../../../../src/state/useTotalXp";


export default function SubtopicScreen() {
  const router = useRouter();
  const { topicId, subtopicId } = useLocalSearchParams<{
    topicId: string;
    subtopicId: string;
  }>();

  const totalXP = useTotalXp();
  const streak = useStreak();

  const topic = TOPIC_BY_ID[String(topicId)];
  const subtopic = topic?.subtopics.find((s) => s.id === String(subtopicId));

  const [completedLevels, setCompletedLevels] = useState<number[]>([]);
  const completedSet = useMemo(() => new Set(completedLevels), [completedLevels]);
  
  const subtopicLevel = useMemo(() => {
  const totalLevels = subtopic?.levels?.length ?? 0;
  if (totalLevels <= 0) return 1;

  const maxDone = completedLevels.length ? Math.max(...completedLevels) : 0;
  return Math.min(Math.max(maxDone, 1), totalLevels);

}, [completedLevels, subtopic?.levels?.length]);


  const refreshProgress = useCallback(() => {
    let alive = true;

    (async () => {
      const progress = await loadProgress();
      const done = progress.completedLevels?.[String(topicId)]?.[String(subtopicId)] ?? [];
      if (alive) setCompletedLevels(done);
    })();

    return () => {
      alive = false;
    };
  }, [topicId, subtopicId]);

  useFocusEffect(refreshProgress);

  if (!topic || !subtopic) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Unknown subtopic</Text>
        <Pressable style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backText}>← Back</Text>
        </Pressable>
      </View>
    );
  }

  const isUnlocked = (levelNumber: number) => {
    if (levelNumber <= 1) return true;
    return completedSet.has(levelNumber - 1);
  };

  const isCompleted = (levelNumber: number) => completedSet.has(levelNumber);

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backText}>← Back</Text>
        </Pressable>

        <Text numberOfLines={1} style={styles.headerTitle}>
          {topic.emoji} {topic.title} • {subtopic.title}
        </Text>

        <View style={styles.xpPill}>
          <Text style={styles.xpText}>
            🔥 {streak} • Lv {subtopicLevel} • XP {totalXP}
          </Text>
        </View>
      </View>

      <Text style={styles.subtitle}>Choose a level</Text>

      {subtopic.levels.map((lvl) => {
        const n = Number(lvl.id);
        const levelNumber = Number.isFinite(n) && n > 0 ? n : 1;

        const locked = !isUnlocked(levelNumber);
        const done = isCompleted(levelNumber);

        return (
          <Pressable
            key={lvl.id}
            style={[
              styles.card,
              { borderLeftColor: topic.color, opacity: locked ? 0.45 : 1 },
            ]}
            disabled={locked}
            onPress={() =>
              router.push(
                `/quiz/${topic.id}/${subtopic.id}/${lvl.id}?set=${lvl.questionSetId}`
              )
            }
          >
            <Text style={styles.cardTitle}>
              {lvl.title} {done ? "✅" : locked ? "🔒" : ""}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#050816",
    paddingHorizontal: 24,
    paddingTop: 60,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  backButton: {
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#3B82F6",
  },
  backText: { color: "#BFDBFE", fontSize: 14, fontWeight: "600" },
  headerTitle: {
    color: "#E5F3FF",
    fontSize: 14,
    fontWeight: "700",
    flex: 1,
    textAlign: "center",
    marginHorizontal: 12,
  },
  subtitle: { color: "#B3C7E6", textAlign: "center", marginBottom: 16, fontSize: 14 },
  card: {
    backgroundColor: "#1F2937",
    padding: 16,
    borderRadius: 14,
    marginBottom: 12,
    borderLeftWidth: 4,
  },
  cardTitle: { color: "#E5F3FF", fontSize: 18, fontWeight: "700" },
  title: {
    fontSize: 22,
    fontWeight: "700",
    color: "#E5F3FF",
    textAlign: "center",
    marginBottom: 12,
  },
  value: {
    fontSize: 16,
    color: "#B3C7E6",
    textAlign: "center",
  },
  xpPill: {
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#F97316",
    marginLeft: 10,
  },
  xpText: {
    color: "#FDBA74",
    fontSize: 13,
    fontWeight: "800",
  },
});
