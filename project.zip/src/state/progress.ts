import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "quizgame_progress_v1";

export type Progress = {
  totalXP: number;
  completedLevels: Record<string, Record<string, number[]>>;
  streakCount: number;
  lastPlayedDate: string | null; // YYYY-MM-DD
};

const DEFAULT_PROGRESS: Progress = {
  totalXP: 0,
  completedLevels: {},
  streakCount: 0,
  lastPlayedDate: null,
};

let inMemory: Progress | null = null;

function normalize(progress: Partial<Progress>): Progress {
  const completedLevels: Progress["completedLevels"] = {};

  const src = progress.completedLevels ?? {};
  for (const topicId of Object.keys(src)) {
    completedLevels[topicId] = {};
    for (const subtopicId of Object.keys(src[topicId] ?? {})) {
      const arr = src[topicId][subtopicId] ?? [];
      completedLevels[topicId][subtopicId] = Array.from(new Set(arr)).sort((a, b) => a - b);
    }
  }

  return {
    totalXP: Number.isFinite(progress.totalXP) ? progress.totalXP! : 0,
    completedLevels,
    streakCount: Number.isFinite(progress.streakCount) ? progress.streakCount! : 0,
    lastPlayedDate: typeof progress.lastPlayedDate === "string" ? progress.lastPlayedDate : null,
  };
}

export async function loadProgress(): Promise<Progress> {
  if (inMemory) return inMemory;

  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) {
      inMemory = DEFAULT_PROGRESS;
      return inMemory;
    }
    inMemory = normalize(JSON.parse(raw));
    return inMemory;
  } catch {
    inMemory = DEFAULT_PROGRESS;
    return inMemory;
  }
}

export async function saveProgress(progress: Progress): Promise<void> {
  const normalized = normalize(progress);
  inMemory = normalized;
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
}

export const XP_PER_CORRECT = 5;
export const XP_LEVEL_BONUS = 10;
export const XP_STREAK_3_BONUS = 5;
export const XP_STREAK_7_BONUS = 10;
export const XP_STREAK_14_BONUS = 20;

export function getStreakBonusXp(streakCount: number): number {
  if (streakCount >= 14) return XP_STREAK_14_BONUS;
  if (streakCount >= 7) return XP_STREAK_7_BONUS;
  if (streakCount >= 3) return XP_STREAK_3_BONUS;
  return 0;
}

export async function addXp(amount: number): Promise<void> {
  const progress = await loadProgress();
  await saveProgress({ ...progress, totalXP: progress.totalXP + amount });
}

export async function updateStreak(): Promise<number> {
  const progress = await loadProgress();

  const today = new Date().toISOString().slice(0, 10);
  if (progress.lastPlayedDate === today) return progress.streakCount;

  const y = new Date();
  y.setDate(y.getDate() - 1);
  const yesterday = y.toISOString().slice(0, 10);

  const streakCount =
    progress.lastPlayedDate === yesterday ? progress.streakCount + 1 : 1;

  await saveProgress({
    ...progress,
    streakCount,
    lastPlayedDate: today,
  });
  return streakCount;
}
